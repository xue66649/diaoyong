<?php
/*高德地图开发者key*/
$key = '07f667183c52d49c0c4b437bd361b2ad';
/*是否允许空refer，0为不允许，1为允许*/
$referopen="1";
