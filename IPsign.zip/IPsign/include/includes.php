<?php
include 'include/function.php';
include 'include/inform.php';
include 'config.php';
?>